MAKANAJA WEBSITE
=================

Isi:
- index.html       Struktur halaman website
- style.css        Tampilan responsif dan warna brand
- script.js        Interaksi menu mobile, filter menu, favorit, dan notifikasi
- assets/          Logo dan ikon aplikasi yang diambil dari gambar identitas brand yang diberikan

Cara menjalankan:
1. Ekstrak ZIP.
2. Buka index.html di browser.
3. Untuk hasil terbaik, gunakan koneksi internet karena font dan foto menu mengambil sumber online.

Catatan penting:
- Foto, menu, harga, rating, alamat email, dan kanal sosial pada website ini adalah contoh/demo. Sesuaikan dengan data bisnis MakanAja yang sebenarnya.
- Tombol menu saat ini berupa demonstrasi interaksi, belum tersambung ke WhatsApp, payment gateway, atau sistem pemesanan.
- Warna mengikuti brand board: #FF7A1A, #FFA76B, #FFD9B3, #FFF8F2.
